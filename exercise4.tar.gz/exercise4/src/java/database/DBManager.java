package database;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import database.UserBean;



public class DBManager {

	private Connection conn;
        private Statement statement;

	public DBManager() throws FileNotFoundException, IOException {
		conn = dbConnect();
        }

	public Connection dbConnect() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/exercise4", "root", "");
			return conn;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
        
        public void addUser(UserBean user) {
            
            String sqlQuery = "INSERT INTO `exercise4`.`users`(`firstName`,`surName`,`phone`)" +
						  "VALUES('" +
						  user.getFirstName() + "','" +
						  user.getSurname() + "','" +
                                                  user.getPhoneNo() + "');";
            try {
			statement  = (Statement) conn.createStatement();
			statement.execute(sqlQuery);
		} catch (SQLException e) {
			e.printStackTrace();
		}
            
        }
        
        public ArrayList<UserBean> getUsers() {
            
            ArrayList<UserBean> users = new ArrayList<UserBean>();
            
            String sqlQuery = "SELECT * FROM users ORDER BY `surName`;";
            
		try {
                        statement = null;
			statement = (Statement) conn.createStatement();
			ResultSet rs = statement.executeQuery(sqlQuery);
                        
                        while(rs.next()) {
                            users.add(new UserBean(rs.getString("firstName"),
                                                   rs.getString("surName"),
                                                   rs.getString("phone")));
                        }
                        
		} catch (SQLException e) {
			e.printStackTrace();
		}
                
            return users;
        }
        
}