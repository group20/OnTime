package database;

/**
 *
 * @author paul
 */
public class UserBean {
    
    private String fname;
    private String sname;
    private String phoneNo;
    
    public UserBean(String firstName, String surName, String phone)
    {
        fname = firstName;
        sname = surName;
        phoneNo = phone;
    }
    
    public String getFirstName()
    {
        return fname;
    }
    
    public String getSurname()
    {
        return sname;
    }
    
    public String getPhoneNo()
    {
        return phoneNo;
    }
    
    public void setFirstName(String fName)
    {
        this.fname = fName;
    }
    
    public void getSurname(String sName)
    {
        this.sname = sName;
    }
    
    public void getPhoneNo(String phone)
    {
        this.phoneNo = phone;
    }
    
}
